#include "main.h"
using namespace okapi::literals;

void initialize() {
	sylib::initialize();
	enableDrivePID = true;
	ledStrip1.gradient(0xFF0000, 0xFF0005, 0, 0, false, true);
	ledStrip1.cycle(*ledStrip1, 4, true);
	ledStrip2.gradient(0xFF0000, 0xFF0005, 0, 0, false, true);
	ledStrip2.cycle(*ledStrip1, 4, true);
	
	Task TBH_(tbhCntrl);
	Task PID_(drivePID());
	static Gif gif("/usd/slideshow.gif", lv_scr_act());

//	Task sylibTBH(sylibCntrl);
}