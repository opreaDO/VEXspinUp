#include "main.h"
using namespace okapi::literals;

// Autonomous Settings //
double desiredLatValue = 200;		// Straight-Line Value
double desiredTurnValue = 0;  		// Spin Value

// PID Values //
double lP = 0.0;        			//////////////////////
double lI = 0.0;        			//                  //
double lD = 0.0;        			//      Requires    //
double tP = 0.0;    				//      Tuning      //
double tI = 0.0;    				//                  //
double tD = 0.0;    				//////////////////////

double latError;					// sensorValue - desiredValue (Position)
double latPrevError = 0;			// Position 10ms ago
double latDerivative;				// pidError - pidPrevError (Speed)
double latTotalError = 0;			// totalError = totalError + pidError

double turnError;					// sensorValue - desiredValue (Position)
double turnPrevError = 0;			// Position 10ms ago
double turnDerivative;				// pidError - pidPrevError (Speed)
double turnTotalError = 0;			// totalError = totalError + pidError

bool resPIDEnc = false;
bool enableDrivePID = true;
