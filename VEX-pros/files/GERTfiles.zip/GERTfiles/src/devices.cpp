#include "main.h"
using namespace okapi::literals;

Controller master(E_CONTROLLER_MASTER);
auto ledStrip1 = sylib::Addrled(13, 1, 25);
auto ledStrip2 = sylib::Addrled(13, 2, 25);
Motor leftA(1, E_MOTOR_GEAR_200, false, E_MOTOR_ENCODER_DEGREES);
Motor leftB(2, E_MOTOR_GEAR_200, false, E_MOTOR_ENCODER_DEGREES);
Motor rightA(3, E_MOTOR_GEAR_200, true, E_MOTOR_ENCODER_DEGREES);
Motor rightB(4, E_MOTOR_GEAR_200, true, E_MOTOR_ENCODER_DEGREES);
MotorGroup drive({leftA, leftB, rightA, rightB});
sylib::Motor flyA(15, 3600, false);
sylib::Motor flyB(14, 3600, true);
Motor intake(20, E_MOTOR_GEAR_200, true);
Motor roller(12, E_MOTOR_GEAR_100);
Optical optical(11);
ADIDigitalOut indexer(2);
ADIDigitalOut stringS(1);