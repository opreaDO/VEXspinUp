#include "main.h"
using namespace okapi::literals;

int drivePID() {
	while (enableDrivePID) {
		if (resPIDEnc) {
		resPIDEnc = false;
		leftA.tare_position(); leftB.tare_position(); 
		rightA.tare_position(); rightB.tare_position();}

		double leftApos = leftA.get_position();
		double leftBpos = leftB.get_position();
		double rightApos = rightA.get_position();
		double rightBpos = rightB.get_position();

		double avgLatPos = (leftApos + leftBpos + rightApos + rightBpos) / 4;
		latError = avgLatPos - desiredLatValue;
		latDerivative = latError - latPrevError;
		latTotalError += latError;
		double latPower = (latError * lP) + (latDerivative * lD) + (latTotalError * lI);

		double avgTurnPos = (leftApos - leftBpos - rightApos - rightBpos) / 4;
		turnError = avgTurnPos - desiredTurnValue;
		turnDerivative = turnError - turnPrevError;
		turnTotalError += turnError;
		double turnPower = (turnError * tP) + (turnDerivative * tD) + (turnTotalError * tI);

		leftA.move_voltage(latPower + turnPower);
		leftB.move_voltage(latPower + turnPower);
		rightA.move_voltage(latPower - turnPower);
		rightB.move_voltage(latPower - turnPower);

		latPrevError = latError;
		turnPrevError = turnError;

		Task::delay(10);
	} return 1;}