#include "main.h"
using namespace okapi::literals;

extern Controller master;
extern auto ledStrip1;
extern auto ledStrip2;
extern Motor leftA;
extern Motor leftB;
extern Motor rightA;
extern Motor rightB;
extern MotorGroup drive;
extern sylib::Motor flyA;
extern sylib::Motor flyB;
extern Motor intake;
extern Motor roller;
extern Optical optical;
extern ADIDigitalOut indexer;
extern ADIDigitalOut stringS;
extern okapi::ChassisModel chassis;