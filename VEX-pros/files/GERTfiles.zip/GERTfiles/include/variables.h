extern double desiredLatValue = 200;		// Straight-Line Value
extern double desiredTurnValue = 0;  		// Spin Value

// PID Values //
extern double lP;        			//////////////////////
extern double lI;        			//                  //
extern double lD;        			//      Requires    //
extern double tP;    				//      Tuning      //
extern double tI ;    				//                  //
extern double tD;    				//////////////////////

extern double latError;					// sensorValue - desiredValue (Position)
extern double latPrevError;			// Position 10ms ago
extern double latDerivative;				// pidError - pidPrevError (Speed)
extern double latTotalError;			// totalError = totalError + pidError

extern double turnError;					// sensorValue - desiredValue (Position)
extern double turnPrevError;			// Position 10ms ago
extern double turnDerivative;				// pidError - pidPrevError (Speed)
extern double turnTotalError;			// totalError = totalError + pidError

extern bool resPIDEnc;
extern bool enableDrivePID;
